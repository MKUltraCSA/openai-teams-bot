declare const config: {
    botId: string;
    botPassword: string;
    openAIKey: string;
    azureOpenAIKey: string;
    azureOpenAIEndpoint: string;
};
export default config;
