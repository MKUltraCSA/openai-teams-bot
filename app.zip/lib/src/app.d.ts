import { Application } from "@microsoft/teams-ai";
declare const app: Application<import("@microsoft/teams-ai").DefaultTurnState<import("@microsoft/teams-ai").DefaultConversationState, import("@microsoft/teams-ai").DefaultUserState, import("@microsoft/teams-ai").DefaultTempState>>;
export default app;
